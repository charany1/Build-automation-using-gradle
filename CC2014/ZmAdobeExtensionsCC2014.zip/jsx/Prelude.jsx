$._ext_PRLD={
    run : function() {
    
    	/**********  Replace below sample code with your own JSX code  **********/
        var appName;	    
	    appName = "Hello Prelude";	    
        alert(appName);
        /************************************************************************/
        
        return appName;
    },
};